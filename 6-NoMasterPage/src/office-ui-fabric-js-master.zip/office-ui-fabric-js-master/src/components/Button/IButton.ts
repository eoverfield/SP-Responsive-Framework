interface IButton {
  container?: Element;
  label?: string;
  icon?: string;
  modifier?: string;
  tag?: string;
}
