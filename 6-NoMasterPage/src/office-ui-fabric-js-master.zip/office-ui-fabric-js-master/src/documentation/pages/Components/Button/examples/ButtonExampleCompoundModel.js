var ButtonExampleCompoundModel =  {
  "label": "Create Account",
  "description": "Description of this action this button takes",
  "icon": "plus",
  "modifier": "compound",
  "tag": "button"
}

module.exports = ButtonExampleCompoundModel;