var SpinnerLargeExampleModel = {
  modifier: "large"
}

module.exports = SpinnerLargeExampleModel;