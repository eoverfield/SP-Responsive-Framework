var LinkModels = {  
   "label": "Example Link",
   "href": "#",
   "title": "More info about Example Link",
   "tabIndex": ""
}

module.exports = LinkModels;