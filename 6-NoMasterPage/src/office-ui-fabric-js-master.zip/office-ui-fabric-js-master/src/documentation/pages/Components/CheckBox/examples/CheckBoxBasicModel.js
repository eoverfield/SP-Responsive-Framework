var CheckBoxModel = {
  "label": "Checkbox",
  "modifier": "",
  "name": "checkboxa",
  "id": "checkboxa",
  "checked": false,
  "disabled": false,
  "type": "checkbox"
}

module.exports = CheckBoxModel;