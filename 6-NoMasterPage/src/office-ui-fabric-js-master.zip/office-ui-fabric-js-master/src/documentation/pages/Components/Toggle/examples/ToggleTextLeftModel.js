var ToggleTextLeftModel = {
   "modifier": "textLeft",
   "description": "Let apps use my location",
   "onText": "On",
   "offText": "Off",
   "demoID": "demo-toggle-1"
}

module.exports = ToggleTextLeftModel;