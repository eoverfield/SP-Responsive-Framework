var TextFieldDisabledExampleModel = {
  "label": "Name",
  "textfield": true,
  "disabled": true
}

module.exports = TextFieldDisabledExampleModel;