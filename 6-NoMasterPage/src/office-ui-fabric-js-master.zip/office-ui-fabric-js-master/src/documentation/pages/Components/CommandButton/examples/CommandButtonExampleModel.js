var CommandButtonExampleModel = {
  "label": "Command",
  "icon": "CircleRing",
  "tag": "button",
  "iconColor": "themePrimary"
}

module.exports = CommandButtonExampleModel;