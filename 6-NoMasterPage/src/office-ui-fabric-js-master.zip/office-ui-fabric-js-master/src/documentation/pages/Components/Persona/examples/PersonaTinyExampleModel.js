var PersonaExampleProps = {
  "primaryText": "Alton Lafferty",
  "icon": "SkypeCheck",
  "modifiers":  [
    {
      "name": "tiny"
    }
  ]
}

module.exports = PersonaExampleProps;
