var ButtonExampleModel = {
  "label": "Create Account",
  "tag": "button"
}

module.exports = ButtonExampleModel;