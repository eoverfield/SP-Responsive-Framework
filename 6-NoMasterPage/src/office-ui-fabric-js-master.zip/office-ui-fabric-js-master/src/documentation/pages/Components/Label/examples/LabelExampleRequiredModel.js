var LabelExampleRequiredModel = {
   "label": "Name",
   "state": "is-required"
}

module.exports = LabelExampleRequiredModel;
