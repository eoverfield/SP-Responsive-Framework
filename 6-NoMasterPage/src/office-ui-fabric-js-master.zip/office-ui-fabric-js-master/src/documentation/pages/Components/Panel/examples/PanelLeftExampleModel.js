var PanelExampleProps = {
  "button": {
    "label": "Open Panel",
    "tag": "button"
  },
  "headerText": "Left Panel",
  "content": "Content goes here",
  "modifier": [
    {
      "name": "left"
    }
  ]
}

module.exports = PanelExampleProps;