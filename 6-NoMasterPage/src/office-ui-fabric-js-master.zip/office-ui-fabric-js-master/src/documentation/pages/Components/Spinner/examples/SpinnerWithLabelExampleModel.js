var SpinnerWithLabelExampleModel = {
  label: "Loading..."
}

module.exports = SpinnerWithLabelExampleModel;
