var ListItemModels = {  
  "primaryText": "Alton Lafferty",
  "secondaryText": "Meeting notes",
  "metaText": "2:42p",
  "modifier": "document",
  "listIcon": "ppt",
  "actions": [{}]
}

module.exports = ListItemModels;