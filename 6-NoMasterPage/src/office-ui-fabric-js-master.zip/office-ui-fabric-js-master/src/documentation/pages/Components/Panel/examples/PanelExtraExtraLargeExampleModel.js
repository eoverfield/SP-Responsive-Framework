var PanelExampleProps = {
  "button": {
    "label": "Open Panel",
    "tag": "button"
  },
  "headerText": "Extra extra large panel",
  "content": "Content goes here",
  "modifier": [
    {
      "name": "xxl"
    }
  ]
}

module.exports = PanelExampleProps;