var CommandButtonExampleModel = {
  "icon": "CircleRing",
  "modifier": "noLabel",
  "tag": "button",
  "iconColor": "themePrimary"
}

module.exports = CommandButtonExampleModel;