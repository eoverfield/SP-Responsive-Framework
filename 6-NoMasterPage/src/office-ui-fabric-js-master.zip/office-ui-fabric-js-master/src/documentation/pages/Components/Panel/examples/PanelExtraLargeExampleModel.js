var PanelExampleProps = {
  "button": {
    "label": "Open Panel",
    "tag": "button"
  },
  "headerText": "Extra large panel",
  "content": "Content goes here",
  "modifier": [
    {
      "name": "xl"
    }
  ]
}

module.exports = PanelExampleProps;
