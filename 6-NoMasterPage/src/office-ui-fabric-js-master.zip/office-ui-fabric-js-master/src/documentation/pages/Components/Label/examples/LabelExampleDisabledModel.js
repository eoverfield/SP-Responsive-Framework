var LabelExampleModel = {
   "label": "Name",
   "state": "is-disabled"
}

module.exports = LabelExampleModel;