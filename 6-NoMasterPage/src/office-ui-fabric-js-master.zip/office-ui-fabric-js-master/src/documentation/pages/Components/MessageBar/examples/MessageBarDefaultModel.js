var MessageBarExampleProps = {
  "iconModifiers": "ms-Icon--Info"
}

module.exports = MessageBarExampleProps;
