var CommandButtonExampleModel = {
  "label": "Command",
  "icon": "CircleRing",
  "tag": "button",
  "modifier": "inline",
  "iconColor": "green"
}

module.exports = CommandButtonExampleModel;