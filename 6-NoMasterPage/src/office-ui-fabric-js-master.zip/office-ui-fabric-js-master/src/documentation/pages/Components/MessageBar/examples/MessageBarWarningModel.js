var MessageBarExampleProps = {
  "modifier": "ms-MessageBar--warning",
  "iconModifiers": "ms-Icon--Info"
}

module.exports = MessageBarExampleProps;
