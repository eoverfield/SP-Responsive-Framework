var OverlayModels = {
  "modifier": "dark"
}

module.exports = OverlayModels;