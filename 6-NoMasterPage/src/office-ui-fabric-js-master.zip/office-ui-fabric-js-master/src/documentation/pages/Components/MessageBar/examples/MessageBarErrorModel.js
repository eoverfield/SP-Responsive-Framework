var MessageBarExampleProps = {
  "modifier": "ms-MessageBar--error",
  "iconModifiers": "ms-Icon--ErrorBadge"
}

module.exports = MessageBarExampleProps;
