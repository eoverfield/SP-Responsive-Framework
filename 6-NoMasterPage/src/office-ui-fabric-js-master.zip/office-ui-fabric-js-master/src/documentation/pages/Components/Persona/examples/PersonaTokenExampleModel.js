var PersonaExampleProps = {
  "image": "https://static2.sharepointonline.com/files/fabric/office-ui-fabric-js/images/persona.person.png",
  "primaryText": "Gerrad Matteu",
  "actionIcon": "x",
  "icon": "SkypeCheck",
  "modifiers": [
    {
      "name": "token"
    }
  ]
}

module.exports = PersonaExampleProps;
