var PersonaExampleProps = {
  "image": "https://static2.sharepointonline.com/files/fabric/office-ui-fabric-js/images/persona.person.png",
  "primaryText": "Alton Lafferty",
  "secondaryText": "Accountant",
  "modifiers":  [
    {
      "name": "offline"
    }
  ]
}

module.exports = PersonaExampleProps;
