var PanelExampleProps = {
  "button": {
    "label": "Open Panel",
    "tag": "button"
  },
  "headerText": "Medium Panel",
  "content": "Content goes here",
  "modifier": [
    {
      "name": "md"
    }
  ]
}

module.exports = PanelExampleProps;