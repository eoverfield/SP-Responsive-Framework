var PersonaExampleProps = {
  "initials": "AL",
  "initialsColor": "blue",
  "primaryText": "Alton Lafferty",
  "icon": "SkypeCheck"
}

module.exports = PersonaExampleProps;
