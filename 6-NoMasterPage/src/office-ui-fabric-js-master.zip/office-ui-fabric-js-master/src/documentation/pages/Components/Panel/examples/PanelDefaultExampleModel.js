  var PanelExampleProps = {
  "button": {
    "label": "Open Panel",
    "tag": "button"
  },
  "headerText": "Panel",
  "content": "Content goes here"
}

module.exports = PanelExampleProps;
