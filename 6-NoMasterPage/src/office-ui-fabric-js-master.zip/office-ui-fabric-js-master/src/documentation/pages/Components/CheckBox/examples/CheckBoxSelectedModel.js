var CheckBoxModel = {
  "label": "Checkbox selected",
  "modifier": "",
  "name": "checkboxc",
  "id": "checkboxc",
  "checked": true,
  "disabled": false,
  "type": "checkbox"
}

module.exports = CheckBoxModel;