var CommandButtonExampleModel = {
  "modifier": "TextOnly",
  "label": "Command",
  "tag": "button"
}

module.exports = CommandButtonExampleModel;