var PanelExampleProps = {
  "button": {
    "label": "Open Panel",
    "tag": "button"
  },
  "headerText": "Large panel",
  "content": "Content goes here",
  "modifier": [
    {
      "name": "lg"
    }
  ]
}

module.exports = PanelExampleProps;
