var SpinnerLargeWithLabelExampleModel = {
  label: "Loading...",
  modifier: "large"
}

module.exports = SpinnerLargeWithLabelExampleModel;