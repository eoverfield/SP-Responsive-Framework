var ToggleDisabledModel = {
  "description": "Let apps use my location",
  "onText": "On",
  "offText": "Off",
  "demoID": "demo-toggle-2",
  "disabled": true
}

module.exports = ToggleDisabledModel;