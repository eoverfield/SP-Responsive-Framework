var DropdownDisabledExampleModel = {
   "label": "Dropdown label",
   "state": "is-disabled",
   "items": [
      {
        "name": "Choose a sound&hellip;"  
      },
      {
        "name": "Dog barking"
      },
      {
        "name": "Wind blowing"
      }, 
      {
        "name": "Duck quacking"
      },
      {
        "name": "Cow mooing"
      }
   ]
}

module.exports = DropdownDisabledExampleModel;