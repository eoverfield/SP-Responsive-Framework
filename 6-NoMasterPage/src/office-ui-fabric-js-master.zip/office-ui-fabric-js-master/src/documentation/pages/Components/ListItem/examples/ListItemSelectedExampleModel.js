var ListItemModels = {  
  "primaryText": "Alton Lafferty",
  "secondaryText": "Meeting notes",
  "tertiaryText": "Today we discussed the importance of a, b, and c in regards to d.",
  "metaText": "2:42p",
  "state": "is-selected is-selectable",
  "actions": [{}]
}

module.exports = ListItemModels;