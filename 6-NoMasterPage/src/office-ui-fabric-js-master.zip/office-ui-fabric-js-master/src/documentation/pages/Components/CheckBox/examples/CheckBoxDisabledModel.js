var CheckBoxModel = {
  "label": "Checkbox Disabled",
  "modifier": "",
  "name": "checkboxb",
  "id": "checkboxb",
  "checked": false,
  "disabled": true,
  "type": "checkbox"
}

module.exports = CheckBoxModel;