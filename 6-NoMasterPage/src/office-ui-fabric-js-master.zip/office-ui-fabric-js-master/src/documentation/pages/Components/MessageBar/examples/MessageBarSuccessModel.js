var MessageBarExampleProps = {
  "modifier": "ms-MessageBar--success",
  "iconModifiers": "ms-Icon--Completed"
}

module.exports = MessageBarExampleProps;
