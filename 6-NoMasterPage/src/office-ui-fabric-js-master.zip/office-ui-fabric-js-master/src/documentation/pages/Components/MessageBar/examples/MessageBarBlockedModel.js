var MessageBarExampleProps = {
  "modifier": "ms-MessageBar--blocked",
  "iconModifiers": "ms-Icon--Blocked"
}

module.exports = MessageBarExampleProps;
