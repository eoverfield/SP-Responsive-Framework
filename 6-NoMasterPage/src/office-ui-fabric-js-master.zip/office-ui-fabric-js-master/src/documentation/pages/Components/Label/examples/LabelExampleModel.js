var LabelExampleModel = {
  "label": "Name"
}

module.exports = LabelExampleModel;