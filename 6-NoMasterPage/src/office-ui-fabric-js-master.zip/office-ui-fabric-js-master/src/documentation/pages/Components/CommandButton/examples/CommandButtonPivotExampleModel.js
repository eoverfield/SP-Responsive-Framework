var CommandButtonExampleModel = {
  "label": "New",
  "icon": "CircleRing",
  "tag": "button",
  "dropdownIcon": "ChevronDown",
  "iconColor": "themePrimary",
  "state": "is-active",
  "modifier": "pivot"
}

module.exports = CommandButtonExampleModel;