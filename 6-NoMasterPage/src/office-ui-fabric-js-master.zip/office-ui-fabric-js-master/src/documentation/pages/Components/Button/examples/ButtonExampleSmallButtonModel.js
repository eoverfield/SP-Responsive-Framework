var ButtonExampleSmallButtonModel = {
  "label": "Create",
  "modifier": "small",
  "tag": "button"
}

module.exports = ButtonExampleSmallButtonModel;