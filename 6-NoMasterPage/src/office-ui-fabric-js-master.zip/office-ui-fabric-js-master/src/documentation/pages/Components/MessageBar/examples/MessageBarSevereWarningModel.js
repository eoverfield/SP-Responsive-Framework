var MessageBarExampleProps = {
  "modifier": "ms-MessageBar--severeWarning",
  "iconModifiers": "ms-Icon--Warning"
}

module.exports = MessageBarExampleProps;
