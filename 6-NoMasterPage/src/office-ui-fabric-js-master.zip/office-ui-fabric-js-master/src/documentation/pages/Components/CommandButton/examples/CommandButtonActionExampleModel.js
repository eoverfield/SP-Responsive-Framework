var CommandButtonExampleModel = {
  "icon": "CircleRing",
  "modifier": "actionButton",
  "tag": "button",
  "iconColor": "themePrimary"
}

module.exports = CommandButtonExampleModel;