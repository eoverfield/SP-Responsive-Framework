var TextFieldMultilineExampleModel = {
  "modifier": "multiline",
  "label": "Name",
  "multiline": true
}

module.exports = TextFieldMultilineExampleModel;