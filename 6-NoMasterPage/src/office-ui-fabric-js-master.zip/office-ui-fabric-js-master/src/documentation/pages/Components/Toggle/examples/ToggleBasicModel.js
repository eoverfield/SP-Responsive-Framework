var ToggleModelBasic = {
  "description": "Let apps use my location",
  "onText": "On",
  "offText": "Off",
  "demoID": "demo-toggle-3"
}

module.exports = ToggleModelBasic;