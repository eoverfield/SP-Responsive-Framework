var BreadcrumbModel = {
  baseClass: "ms-Breadcrumb",
  items: [
      {
        "name": "Files"
      },
      {
        "name": "Folder 1"
      },
      {
        "name": "Folder 2"
      },
      {
        "name": "Folder 3"
      },
      {
        "name": "Folder 4"
      },
      {
        "name": "Folder 5"
      },
      {
        "name": "Folder 6"
      },
      {
        "name": "Folder 7"
      }
  ]
}

module.exports = BreadcrumbModel;