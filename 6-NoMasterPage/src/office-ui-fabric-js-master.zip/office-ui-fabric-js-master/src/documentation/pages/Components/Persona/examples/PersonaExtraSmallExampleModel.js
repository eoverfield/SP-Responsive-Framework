var PersonaExampleProps = {
  "image": "https://static2.sharepointonline.com/files/fabric/office-ui-fabric-js/images/persona.person.png",
  "primaryText": "Alton Lafferty",
  "icon": "SkypeCheck",
  "modifiers":  [
    {
      "name": "xs"
    }
  ]
}

module.exports = PersonaExampleProps;
