# Resources

## Samples using Fabric

[Office 365 API - Groups Explorer](https://github.com/OfficeDev/PnP/tree/master/Samples/MicrosoftGraph.Office365.GroupsExplorer)
